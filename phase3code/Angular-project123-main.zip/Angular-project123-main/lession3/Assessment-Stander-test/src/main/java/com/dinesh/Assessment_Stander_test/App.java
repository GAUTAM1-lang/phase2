package com.dinesh.Assessment_Stander_test;

public class App 
{
    public static void main( String[] args )
    {
       
    }
    
    
    int divideNumbers(int firstNum, int secondNum) {
    	return firstNum / secondNum;
    }
    
    boolean checkPalindrome(String value) {
    	if(value.equals("madam"))
    		return true;
    	else
    		return false;
    }
    
}