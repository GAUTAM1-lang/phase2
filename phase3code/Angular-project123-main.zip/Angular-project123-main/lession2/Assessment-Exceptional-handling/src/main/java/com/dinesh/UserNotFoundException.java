package com.dinesh;

public class UserNotFoundException extends RuntimeException{

}
