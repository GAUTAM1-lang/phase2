

package com.Spring_Jdbc1;

record Student(Integer Id, String Name, String Location) {
	
}
