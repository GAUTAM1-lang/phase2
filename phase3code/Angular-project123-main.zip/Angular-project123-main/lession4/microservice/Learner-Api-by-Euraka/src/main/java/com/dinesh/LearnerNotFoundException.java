package com.dinesh;

public class LearnerNotFoundException extends RuntimeException {

}
