package com.dinesh;

record Learner(String name, String location, Integer id) {}
